package com.ambiguous.logic.raw;

/**
 * Created by Kubuś on 2016-03-19.
 */
public enum PieceColor {
    WHITE,
    BLACK
}
