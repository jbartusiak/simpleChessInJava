package com.ambiguous.logic.raw;

/**
 * Created by Kubuś on 2016-03-18.
 */
public enum Type {
    PAWN,
    KNIGHT,
    BISHOP,
    ROOK,
    QUEEN,
    KING
}
