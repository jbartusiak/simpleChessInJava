package com.ambiguous.exception;

/**
 * Created by Kubuś on 2016-03-19.
 */
public class UnimplementedException extends UnsupportedOperationException{
}
