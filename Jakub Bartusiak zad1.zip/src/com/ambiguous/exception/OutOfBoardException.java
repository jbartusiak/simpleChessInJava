package com.ambiguous.exception;

/**
 * Created by Kubuś on 2016-03-18.
 */
public class OutOfBoardException extends IllegalStateException{
    public OutOfBoardException(){
        super();
    }
}
